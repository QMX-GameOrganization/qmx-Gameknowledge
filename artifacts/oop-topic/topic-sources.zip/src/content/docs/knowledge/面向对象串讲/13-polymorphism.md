---
title: "13. 虚函数与动态多态"
description: "从真实调用过程理解 virtual、override、纯虚函数、动态类型、虚析构和虚表的边界。"
sidebar:
  order: 14
---

## 调用代码怎么做到不认识每一种技能

现在不急着用纯虚接口，先用一个可实例化基类对比普通调用和虚调用。下面是完整程序：

```cpp
#include <iostream>

// 普通 label 按静态类型选择；虚 cast 可由实际技能重写。
class Skill {
public:
    virtual ~Skill() = default;
    const char* label() const { return "Skill"; }
    virtual void cast() const { std::cout << "Default\n"; }
};

class Fireball final : public Skill {
public:
    const char* label() const { return "Fireball"; }
    void cast() const override { std::cout << "Fireball\n"; }
};

// 使用方只借用接口，不检查具体类型名字。
void perform(const Skill& skill) {
    std::cout << skill.label() << '\n';
    skill.cast();
}

int main() {
    Fireball fireball;
    perform(fireball); // 依次输出 Skill、Fireball。
}
```

`perform` 编译时只知道 Skill 的接口。非虚 label 选择 Skill 版本，虚 cast 进入 Fireball 版本。`skill` 的静态类型是 `const Skill&`，所引用对象的动态类型是 Fireball。**通过基类指针或引用进行虚调用，才是这里观察的动态多态。** 后面增加治疗实现时，调用方仍可使用相同形式。

![基类引用指向不同派生对象，虚调用进入各自 cast 实现](/qmx-Gameknowledge/assets/oop/dispatch.svg)

非虚成员调用主要按静态类型选择；虚函数调用按虚调用规则选择动态类型对应的最终重写者。不要把它背成“所有函数都运行时查表”：编译器知道具体类型时可能去虚化，显式限定调用也会绕过虚分派。

## 四个关键字的职责

| 写法 | 表达什么 | 常见误解 |
| --- | --- | --- |
| `virtual` | 基类声明可被重写的行为 | 不是每个成员都需要 virtual |
| `= 0` | 纯虚函数，使类型在相应条件下为抽象类 | 不代表派生类也不能有状态 |
| `override` | 请求编译器确认确实重写了基类虚函数 | 签名写错时能阻止“以为重写成功” |
| `final` | 禁止继续派生，或禁止某虚函数继续重写 | 表达边界，不是通用加速开关 |

抽象类不能直接创建完整实例，但可以作为派生对象中的基类部分。基类指针和引用可以指向或引用完整派生对象。C++ 没有独立 `interface` 关键字，常用只含纯虚行为及合适析构的抽象基类表达接口。

## 为什么必须讨论析构函数

```cpp
std::unique_ptr<Skill> skill = std::make_unique<Fireball>();
```

这一独占所有者销毁对象时，通过 `Skill*` 删除实际派生对象。对本专题这种普通基类删除方式，`Skill` 必须有可访问的虚析构函数，否则会导致未定义行为，不能只理解成“少打印一行派生析构”。

常用设计是 `public virtual ~Skill() = default;`，允许通过基类销毁。另一种设计是受保护的非虚析构，明确禁止普通外部代码通过基类删除；它不适用于上面这种 `unique_ptr<Skill>` 默认删除器用法。纯虚析构即使写 `= 0`，仍然需要提供定义；入门接口直接使用默认虚析构最清楚。

## 虚表能解释到什么程度

常见 ABI 会为多态对象关联虚表指针，虚表记录相关虚函数入口；一次典型虚调用会经由这些信息找到实现。它帮助理解间接调用、对象可能变大以及为什么需要实际对象仍然存活。

但 C++ 标准不要求所有实现采用完全相同的虚表形状，不保证指针数量、字段偏移和精确开销。多继承、虚继承、优化级别与平台 ABI 都可能影响布局。图中的一条箭头是语义关系，不是可移植的内存偏移。

## 多态也有其他工具

| 方案 | 适合的变化 | 要付出的代价 |
| --- | --- | --- |
| 普通函数与配置表 | 算法一致，参数不同 | 数据模式和规则解释器需要保持一致 |
| 模板 | 编译时已知类型，需要泛型复用 | 编译依赖、错误信息和代码体积 |
| `std::variant` + `visit` | 类型集合固定，希望显式覆盖 | 添加类型可能修改访问者 |
| 虚接口 | 运行时选择行为，独立实现可扩展 | 生命周期、间接调用与接口演化 |
| `std::function` | 把一个可调用行为作为参数保存 | 类型擦除，可能分配和捕获寿命问题 |

动态多态的价值是把“使用行为”与“选择具体实现”分开，不是自动提升性能。若大量同质数据逐项虚调用成为瓶颈，先测量，再考虑按类型分组、批处理或数据布局调整。

**自测：** 将 perform 参数改成 `Skill skill` 会怎样？本章基类可实例化，但按值接收会切片，两次输出都按新的 Skill 对象执行。下一章再把基类改成抽象接口，届时连这种按值创建都不允许。

下一章：[纯虚函数、抽象类与虚析构](../14-abstract-interfaces/)。
